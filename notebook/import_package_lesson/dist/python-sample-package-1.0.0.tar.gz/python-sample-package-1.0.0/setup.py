from distutils.core import setup

setup(
    name='python-sample-package',
    version='1.0.0',
    packages=['package', 'package.talk', 'package.tools'],
    url='',
    license='Free',
    author='Ryo Kawanami',
    author_email='',
    description='Python Sample Package'
)